﻿namespace DesktopApp1
{
    internal class Students
    {
        public string firstname { get; set; }
        public string lastname { get; set; }

    }
}